                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2289371
ErgoDox Keycaps by geodynamics is licensed under the GNU - GPL license.
http://creativecommons.org/licenses/GPL/2.0/

# Summary

These are my keycap designs for the ErgoDox (or any keyboard).

I have tried to take a step towards the curvature found on the Kinesis Advantage.
I have based my designs on the [Parametric Cherry MX/Alps Keycap](www.thingiverse.com/thing:468651) thing.
The most common keycap profiles are DCS (Cylindrical) and SA (Spherical), however their angle is not pronounced enough.
I basically took the SA profile and tilted the rows at 10 and 20 degrees creating a much larger curve and making the farthest keys easier to reach. 

The following enhancements were made:
- Added multi row text with offset adjustment.
- Added support for icon designs recessed.
- Added GSA profile that is more inclined than SA (G is the first letter of my name).
- Added stem rotation because the Infinity ErgoDox has the long 2x1 and 1.5x1 switches rotated 90 degrees.
- Added extra support to hold the stabilizer stems for the 2x1 keys at their highest point.

To use this design, download the OpenSCAD files.
The main file is keyboard.scad. It has many, many examples are commented out. Because it take a long time to render each batch, I comment a few back in before rendering the STL files.

The keycap stems fit both Cherry MX and Gateron switches (see pictures: Infinity and EZ).

Printing:
Nothing special needed to print the keycaps.
Maybe a very little filing of inside of the stems might be needed if they are too tight to fit onto the switches. I have used many printers and most fit perfectly out of the box.